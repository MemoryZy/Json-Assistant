package cn.memoryzy.json.action.transform;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.project.DumbAwareAction;
import org.jetbrains.annotations.NotNull;

/**
 * @author Memory
 * @since 2024/11/4
 */
public class ToJson5Action extends DumbAwareAction {

    @Override
    public void actionPerformed(@NotNull AnActionEvent event) {
        // TODO 待实现
    }


}
