package cn.memoryzy.json.action.extend;

import cn.memoryzy.json.bundle.JsonAssistantBundle;
import cn.memoryzy.json.enums.JsonValueHandleType;
import cn.memoryzy.json.model.strategy.GlobalTextConverter;
import cn.memoryzy.json.model.strategy.formats.data.EditorData;
import cn.memoryzy.json.util.JsonValueHandler;
import cn.memoryzy.json.util.PlatformUtil;
import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataContext;
import com.intellij.openapi.actionSystem.Presentation;
import com.intellij.openapi.actionSystem.UpdateInBackground;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.project.DumbAwareAction;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;

/**
 * @author Memory
 * @since 2025/3/31
 */
public class ConvertAllReadableTimeAction extends DumbAwareAction implements UpdateInBackground {

    public ConvertAllReadableTimeAction() {
        super();
        setEnabledInModalContext(true);
        Presentation presentation = getTemplatePresentation();
        presentation.setText(JsonAssistantBundle.message("action.convert.to.timestamp.text"));
        presentation.setDescription(JsonAssistantBundle.messageOnSystem("action.convert.to.timestamp.description"));
    }

    @Override
    public void actionPerformed(@NotNull AnActionEvent e) {
        Project project = getEventProject(e);
        DataContext dataContext = e.getDataContext();
        // 解析编辑器信息
        Editor editor = PlatformUtil.getEditor(dataContext);
        EditorData editorData = GlobalTextConverter.resolveEditor(editor);
        // PsiFile psiFile = PlatformUtil.getPsiFile(dataContext, editor.getDocument());

        // if (psiFile instanceof JsonFile) {
            // Psi 操作太慢
            // JsonValueHandler.handleAllElement(project, psiFile, editorData, JsonValueHandleType.READABLE_TIME);
        // } else {
            JsonValueHandler.handleAllWrapper(project, dataContext, editorData, JsonValueHandleType.READABLE_TIME);
        // }
    }

    @Override
    public void update(@NotNull AnActionEvent e) {
        e.getPresentation().setEnabledAndVisible(containsSpecialType(e.getDataContext()));
    }

    public static boolean containsSpecialType(DataContext dataContext) {
        return JsonValueHandler.containsSpecialType(dataContext, JsonValueHandleType.READABLE_TIME);
    }
}
